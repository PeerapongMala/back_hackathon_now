package ac.th.fearfreeanimals.entity;

public class Animal {

}
